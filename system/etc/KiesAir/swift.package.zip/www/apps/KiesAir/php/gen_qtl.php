<?php
	header('Content-Type', 'application/x-quicktimeplayer');
	echo '<?xml version="1.0" encoding="utf-8"?><?quicktime type="application/x-quicktime-media-link"?><embed src="'.$_GET['file'].'" autoplay="true" fullscreen="full" quitwhendone="true"/>';
?>
