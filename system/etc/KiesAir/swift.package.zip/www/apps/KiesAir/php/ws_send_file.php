<?php
require_once(dirname(__FILE__)."/send_file.php");

$mtype = $_GET["mtype"];
if (!$mtype) $mtype="application/octet-stream";
$file = stripslashes($_GET["file"]);
send_file($file,  $mtype, 60, $_GET["contentDisposition"]);
?>
