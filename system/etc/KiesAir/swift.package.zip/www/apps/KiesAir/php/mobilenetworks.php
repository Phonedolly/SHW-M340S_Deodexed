<?php
	header('Content-Type', 'application/json');
	echo '{"items": [{ "id": "gsm", "name": "GSM", "ready": 1 }, { "id": "cdma", "name": "CDMA", "ready": 0 }], "size": 2 }';
?>