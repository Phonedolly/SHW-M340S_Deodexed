<?php
// Disable caching of the current document:
header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header('Pragma: no-cache');

$url = $_SERVER[SERVER_PROTOCOL].'://localhost:'.$_SERVER[SERVER_PORT].$_SERVER[SCRIPT_NAME];
$endpos = strripos($url, "/");
$url = substr($url, 0, $endpos) . '/../';

$source = str_replace("%2F", "/", rawurlencode($_GET['in']));
$saveAs = str_replace("%2F", "/", rawurlencode($_GET['out']));

$source = str_replace("%5C", "", $source);
$saveAs = str_replace("%5C", "", $saveAs);

$destination = "";
$status = "";

if ($source) {
	$startpos = stripos($source, "/file");
	$endpos = strripos($source, "/");
	
	if (($startpos === false) || ($endpos === false)) {
		$status = "{\"status\":\"failure\", \"description\":\"Out file is not set\"}";
	} else {
		$startpos = $startpos + 5; // lenght of "/file" string
		$destination = substr($source, $startpos, $endpos - $startpos);
		if ($saveAs) {
			$endpos = strripos($destination, "/");
			$destination = substr($destination, 0, $endpos) . "/" . $saveAs;
		}
		// Open the file to get existing content
		$source = str_replace(array(" ","%3F","%3D"), array("%20", "?", "="), $source);
		
		$f=fopen($url . $source,'rb');
		$data='';
		while(!feof($f))
    		$data.=fread($f,2048);
		fclose($f); 
		// Write the contents back to the file
		if ($data) {
			$destination = rawurldecode($destination);
			$f = fopen($destination, 'w') or die("{\"status\":\"failure\", \"description\":\"can't open file " . $destination . "\"}");
			fwrite($f, $data);
			fclose($f);
		}
		$status = "{\"status\":\"success\", \"destination\":\"".$destination."\"}";
	}
}

echo ($status);
?>
