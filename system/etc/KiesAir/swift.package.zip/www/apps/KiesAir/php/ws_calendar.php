<?php
$ch = curl_init();
$url = str_replace(":8080", ":8082", $_SERVER['HTTP_HOST']) . $_SERVER['QUERY_STRING'];
//echo($url)
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_exec($ch);
curl_close($ch);
?>