<?php
set_time_limit(0);

$jsCallback = $_POST["jsCallback"];
$destination = $_POST["destination"];
$freesize = $_POST["freesize"];

function checkPath($inPath) {
	//Replace windows slashes
	$checkRoot = strtok($inPath, "\/");
	$checkedPath = "/";
	$pathExist = false;
	
	while ($checkRoot) {
		$checkedPath .= $checkRoot;
	
		if (!is_dir($checkedPath)) {
			$pathExist = mkdir($checkedPath);
		} else {
			$pathExist = true;
		}
		$checkedPath .= "/";
		$checkRoot = strtok("\/");
	}

	return $pathExist;
}

ini_set('memory_limit', '100M'); // handle large files
ini_set('upload_tmp_dir', '/sdcard');

$target_path = "/";
$maxUploadSize = ini_get('upload_max_filesize');
$maxPostSize = ini_get('post_max_size');

$fileName = stripslashes(basename( $_FILES['uploadedfile']['name']));

if ($destination) {
	$target_path .= $destination . "/";
	//Check if target path exist and create if not
	checkPath($target_path);
}
$target_path .= $fileName;

$status = "";
$isError = false;

if (count($_FILES) == 0) {
	$isError = true;
	$status = "{\"status\":\"failure\", \"description\":\"largeFile\"}";
} elseif($_FILES['uploadedfile']['size'] > $freesize) {
	$isError = true;
	$status = "{\"status\":\"failure\", \"description\":\"notEnoughSpace\"}";	
} elseif(move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
	$target_path = rawurlencode($target_path);
	$status = "{\"status\":\"success\", \"destination\":\"".$target_path."\"}";
} else {
	$isError = true;
	$status = "{\"status\":\"failure\", \"description\":\"error\"}";
}

ini_restore('upload_tmp_dir');

if ($isError) {
	if (file_exists($target_path)) {
		unlink($target_path);
	}
	//header('Status: 404 Not Found');
} else {
	// Disable caching of the current document:
	header('Cache-Control: no-cache, no-store, max-age=0, must-revalidate');
	header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
	header('Pragma: no-cache');
}

if ($jsCallback) {
	$status = '<script language="javascript" type="text/javascript">var resp=' . $status . '; window.top.'.$jsCallback.'.uploadFinished(resp);</script>';
}

echo ($status);
?>