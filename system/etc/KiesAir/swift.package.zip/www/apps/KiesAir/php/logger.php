<?
function write_to_file($filename, $data_array, $mode) {
	$file = fopen($filename, $mode);
	fwrite($file, date('H:i:s.u')."\n");
	foreach ($data_array as $value) {
		$value = urldecode($value);
		fwrite($file, $value."\n");
	}
	fclose($file);
}

$filename = $_POST['filename'];
$logdir = '../logs';

if (!is_dir($logdir)) {
	mkdir($logdir, 0777) || die('Error');
}

if (isset($_POST['logs'])) {
	write_to_file($logdir.'/'.$filename.'_logs.txt', $_POST['logs'], 'a+');
}

if (isset($_POST['tests'])) {
	write_to_file($logdir.'/'.$filename.'_tests.txt', $_POST['tests'], 'w');
}

if (isset($_POST['stack'])) {
	write_to_file($logdir.'/'.$filename.'_stack.txt', $_POST['stack'], 'w');
}
?>
